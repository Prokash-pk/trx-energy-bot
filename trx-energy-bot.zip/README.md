# TRX Energy Bot Setup Instructions
Run with python bot/main.py
