# Monitoring logic
